﻿namespace ScraperCoreLib
{
    public interface IGrabData
    {
        GrabbedData Grab(string path);

    }
}
