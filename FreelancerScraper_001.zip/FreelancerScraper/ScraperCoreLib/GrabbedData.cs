﻿using System;

namespace ScraperCoreLib
{
    public class GrabbedData
    {
        public DateTime LastModifiedTimestamp { get; set; }

        public byte[] Data { get; set; }

    }
}
